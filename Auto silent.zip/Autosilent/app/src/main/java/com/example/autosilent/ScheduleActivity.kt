package com.example.autosilent

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class ScheduleActivity : AppCompatActivity() {
    private lateinit var btnSelectStartTime: Button
    private lateinit var btnSelectEndTime: Button
    private lateinit var btnSelectStartDate: Button
    private lateinit var btnSelectEndDate: Button
    private lateinit var btnConfirm: Button
    private lateinit var txtSelectedStartTime: TextView
    private lateinit var txtSelectedEndTime: TextView
    private lateinit var txtSelectedStartDate: TextView
    private lateinit var txtSelectedEndDate: TextView
    private lateinit var spinnerMode: Spinner
    private lateinit var checkMonday: CheckBox
    private lateinit var checkTuesday: CheckBox
    private lateinit var checkWednesday: CheckBox
    private lateinit var checkThursday: CheckBox
    private lateinit var checkFriday: CheckBox
    private lateinit var checkSaturday: CheckBox
    private lateinit var checkSunday: CheckBox
    private lateinit var audioManager: AudioManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_schedule)

        requestDndPermission()

        // Initialize Views
        btnSelectStartTime = findViewById(R.id.btnSelectStartTime)
        btnSelectEndTime = findViewById(R.id.btnSelectEndTime)
        btnSelectStartDate = findViewById(R.id.btnSelectStartDate)
        btnSelectEndDate = findViewById(R.id.btnSelectEndDate)
        btnConfirm = findViewById(R.id.btnConfirm)
        txtSelectedStartTime = findViewById(R.id.txtSelectedStartTime)
        txtSelectedEndTime = findViewById(R.id.txtSelectedEndTime)
        txtSelectedStartDate = findViewById(R.id.txtSelectedStartDate)
        txtSelectedEndDate = findViewById(R.id.txtSelectedEndDate)
        spinnerMode = findViewById(R.id.spinnerMode)
        checkMonday = findViewById(R.id.checkMonday)
        checkTuesday = findViewById(R.id.checkTuesday)
        checkWednesday = findViewById(R.id.checkWednesday)
        checkThursday = findViewById(R.id.checkThursday)
        checkFriday = findViewById(R.id.checkFriday)
        checkSaturday = findViewById(R.id.checkSaturday)
        checkSunday = findViewById(R.id.checkSunday)

        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        setupModeSpinner()

        btnSelectStartTime.setOnClickListener { showTimePickerDialog(txtSelectedStartTime) }
        btnSelectEndTime.setOnClickListener { showTimePickerDialog(txtSelectedEndTime) }
        btnSelectStartDate.setOnClickListener { showDatePickerDialog(txtSelectedStartDate) }
        btnSelectEndDate.setOnClickListener { showDatePickerDialog(txtSelectedEndDate) }
        btnConfirm.setOnClickListener { confirmSchedule() }
    }

    private fun requestDndPermission() {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!notificationManager.isNotificationPolicyAccessGranted) {
            val intent = Intent(android.provider.Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            startActivity(intent)
            Toast.makeText(this, "Please enable DND permission", Toast.LENGTH_LONG).show()
        }
    }

    private fun setupModeSpinner() {
        val modes = arrayOf("Silent", "Vibrate", "Do Not Disturb", "Normal")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, modes)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerMode.adapter = adapter
    }

    private fun showTimePickerDialog(textView: TextView) {
        val calendar = Calendar.getInstance()
        TimePickerDialog(this, { _, selectedHour, selectedMinute ->
            textView.text = String.format("%02d:%02d", selectedHour, selectedMinute)
        }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), false).show()
    }

    private fun showDatePickerDialog(textView: TextView) {
        val calendar = Calendar.getInstance()
        DatePickerDialog(this, { _, selectedYear, selectedMonth, selectedDay ->
            textView.text = String.format("%02d/%02d/%04d", selectedDay, selectedMonth + 1, selectedYear)
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun confirmSchedule() {
        val startTime = txtSelectedStartTime.text.toString()
        val endTime = txtSelectedEndTime.text.toString()
        val startDate = txtSelectedStartDate.text.toString()
        val endDate = txtSelectedEndDate.text.toString()
        val selectedMode = spinnerMode.selectedItem.toString()

        if (startTime.isEmpty() || endTime.isEmpty() || startDate.isEmpty() || endDate.isEmpty()) {
            Toast.makeText(this, "Please select start and end time!", Toast.LENGTH_LONG).show()
            return
        }

        val dateTimeFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        val startDateTime: Date
        val endDateTime: Date

        try {
            startDateTime = dateTimeFormat.parse("$startDate $startTime")!!
            endDateTime = dateTimeFormat.parse("$endDate $endTime")!!
        } catch (e: Exception) {
            Toast.makeText(this, "Invalid date/time format!", Toast.LENGTH_LONG).show()
            return
        }

        // Ensure start time is before end time
        if (!startDateTime.before(endDateTime)) {
            Toast.makeText(this, "Start time must be before end time!", Toast.LENGTH_LONG).show()
            return
        }

        val selectedDays = getSelectedDays()
        if (selectedDays.isEmpty()) {
            Toast.makeText(this, "Please select at least one day!", Toast.LENGTH_LONG).show()
            return
        }

        for (day in selectedDays) {
            scheduleModeChange(startDateTime, selectedMode, "START_$day")
            scheduleModeChange(endDateTime, "Normal", "END_$day")
        }

        Toast.makeText(this, "Scheduled mode: $selectedMode", Toast.LENGTH_LONG).show()
    }


    private fun getSelectedDays(): List<Int> {
        val selectedDays = mutableListOf<Int>()
        if (checkMonday.isChecked) selectedDays.add(Calendar.MONDAY)
        if (checkTuesday.isChecked) selectedDays.add(Calendar.TUESDAY)
        if (checkWednesday.isChecked) selectedDays.add(Calendar.WEDNESDAY)
        if (checkThursday.isChecked) selectedDays.add(Calendar.THURSDAY)
        if (checkFriday.isChecked) selectedDays.add(Calendar.FRIDAY)
        if (checkSaturday.isChecked) selectedDays.add(Calendar.SATURDAY)
        if (checkSunday.isChecked) selectedDays.add(Calendar.SUNDAY)
        return selectedDays
    }

    private fun scheduleModeChange(time: Date, mode: String, tag: String) {
        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, ModeChangeReceiver::class.java).apply {
            putExtra("mode", mode)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            this, tag.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val calendar = Calendar.getInstance().apply {
            timeInMillis = time.time // Set selected time

            // If scheduled time is in the past, schedule it for the next occurrence
            if (before(Calendar.getInstance())) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        Log.d("ScheduleActivity", "⏳ Scheduling $tag for: ${calendar.time}")

        alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pendingIntent)
    }


}

