package com.example.autosilent

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log

class YourForegroundService : Service() {

    override fun onCreate() {
        super.onCreate()
        startForegroundService()
    }

    private fun startForegroundService() {
        val notificationChannelId = "AutoSilentServiceChannel"
        val channelName = "Auto Silent Service"

        val notificationManager = getSystemService(NotificationManager::class.java)

        // ✅ Create Notification Channel (For Android O+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                notificationChannelId,
                channelName,
                NotificationManager.IMPORTANCE_LOW
            )
            notificationManager.createNotificationChannel(channel)
        }

        // ✅ Create Notification
        val notification = Notification.Builder(this, notificationChannelId)
            .setContentTitle("Auto Silent Running")
            .setContentText("Your phone will switch to silent mode automatically")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setPriority(Notification.PRIORITY_LOW) // ✅ Prevents unnecessary popups
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()

        // ✅ Start Foreground Service
        startForeground(1, notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d("YourForegroundService", "Foreground service is running")
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("YourForegroundService", "Foreground service stopped")
    }
}
