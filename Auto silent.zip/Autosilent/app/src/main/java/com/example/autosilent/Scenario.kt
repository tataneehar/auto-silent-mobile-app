package com.example.autosilent

data class Scenario(
    val mode: String,
    val startHour: Int,
    val startMinute: Int,
    val endHour: Int,
    val endMinute: Int,
    val days: List<Int>
)
