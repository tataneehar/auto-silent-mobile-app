package com.example.autosilent

import android.service.notification.NotificationListenerService

class SilentModeService : NotificationListenerService() {
    override fun onListenerConnected() {
        super.onListenerConnected()
    }
}
