package com.example.autosilent

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Build
import android.util.Log
import android.widget.Toast

class ModeChangeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val mode = intent.getStringExtra("mode")

        if (mode == null) {
            Log.e("ModeChangeReceiver", "No mode specified in intent!")
            return
        }

        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        if (audioManager == null) {
            Log.e("ModeChangeReceiver", "AudioManager not available!")
            return
        }

        when (mode) {
            "Silent" -> {
                Log.d("ModeChangeReceiver", "Setting mode: Silent")
                audioManager.ringerMode = AudioManager.RINGER_MODE_SILENT
            }
            "Vibrate" -> {
                Log.d("ModeChangeReceiver", "Setting mode: Vibrate")
                audioManager.ringerMode = AudioManager.RINGER_MODE_VIBRATE
            }
            "Do Not Disturb" -> {
                Log.d("ModeChangeReceiver", "Enabling Do Not Disturb")
                enableDoNotDisturb(context)
            }
            "Normal" -> {
                Log.d("ModeChangeReceiver", "Setting mode: Normal")
                audioManager.ringerMode = AudioManager.RINGER_MODE_NORMAL
            }
            else -> {
                Log.e("ModeChangeReceiver", "Unknown mode: $mode")
            }
        }

        Toast.makeText(context, "Mode changed to: $mode", Toast.LENGTH_SHORT).show()
    }

    private fun enableDoNotDisturb(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (notificationManager.isNotificationPolicyAccessGranted) {
                notificationManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
                Log.d("ModeChangeReceiver", "DND enabled successfully")
            } else {
                Log.e("ModeChangeReceiver", "DND permission not granted")
                Toast.makeText(context, "Enable DND permission in settings!", Toast.LENGTH_LONG).show()
            }
        }
    }
}
