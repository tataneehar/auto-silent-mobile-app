package com.example.autosilent

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioManager

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val mode = intent.getStringExtra("mode") ?: return
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

        when (mode) {
            "Silent" -> audioManager.ringerMode = AudioManager.RINGER_MODE_SILENT
            "Vibrate" -> audioManager.ringerMode = AudioManager.RINGER_MODE_VIBRATE
            "Do Not Disturb" -> audioManager.ringerMode = AudioManager.RINGER_MODE_NORMAL
        }
    }
}
